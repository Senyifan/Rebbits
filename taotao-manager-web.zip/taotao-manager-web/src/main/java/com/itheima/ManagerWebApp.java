package com.itheima;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import tk.mybatis.spring.annotation.MapperScan;


@SpringBootApplication
//这里还需要加上一个注解
@MapperScan("com.itheima.mapper")
    public class ManagerWebApp {

        public static void main(String[] args) {
            SpringApplication.run(ManagerWebApp.class , args);
        }
    }

