package com.itheima;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*
 *  @创建时间:  2020/12/14 11:17
 *  @描述：    TODO
 */
@SpringBootApplication
public class SearchWebApp {

    public static void main(String[] args) {
        SpringApplication.run(SearchWebApp.class , args);
    }
}
