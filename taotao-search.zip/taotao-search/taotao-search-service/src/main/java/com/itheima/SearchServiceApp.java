package com.itheima;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*
 *  @创建时间:  2020/12/14 13:46
 *  @描述：    TODO
 */
@SpringBootApplication
public class SearchServiceApp {

    public static void main(String[] args) {
        SpringApplication.run(SearchServiceApp.class , args);
    }
}
