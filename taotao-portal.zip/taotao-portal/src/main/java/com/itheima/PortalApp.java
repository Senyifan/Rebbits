package com.itheima;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*
 *  @创建时间:  2020/12/11 9:13
 *  @描述：    TODO
 */
@SpringBootApplication
public class PortalApp {

    public static void main(String[] args) {
        SpringApplication.run(PortalApp.class , args);
    }
}
