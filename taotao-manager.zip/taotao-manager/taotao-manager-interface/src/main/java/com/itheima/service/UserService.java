package com.itheima.service;
/*
 *  @创建时间:  2020/12/9 10:13
 *  @描述：    TODO
 */
public interface UserService {
    void findAll();
}
