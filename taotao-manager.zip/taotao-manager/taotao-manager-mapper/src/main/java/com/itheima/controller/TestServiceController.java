package com.itheima.controller;

import com.itheima.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;


public class TestServiceController {

    @Autowired
    private UserService userService;

    @RequestMapping("/all")
    public String findAll(){
        userService.findAll();
        return "success！~！~！";
    }
}
