package com.itheima.mapper;

/**
 * 测试接口，查询数据库的当前时间
 * @author liayun
 *
 */
public interface TestMapper {

	public String queryNow();
	
}
