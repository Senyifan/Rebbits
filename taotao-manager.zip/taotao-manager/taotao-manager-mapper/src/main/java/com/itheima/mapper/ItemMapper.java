package com.itheima.mapper;

import com.itheima.bean.Item;
import tk.mybatis.mapper.common.Mapper;

/*
 *  @创建时间:  2020/12/10 9:05
 *  @描述：    TODO
 */
public interface ItemMapper extends Mapper<Item> {

}
