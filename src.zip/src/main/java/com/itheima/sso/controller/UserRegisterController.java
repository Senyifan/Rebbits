package com.itheima.sso.controller;

import com.itheima.common.pojo.TaotaoResult;
import com.itheima.pojo.TbUser;
import com.itheima.sso.service.UserRegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class UserRegisterController {

    @Autowired
    private UserRegisterService registerService;

    /**
     * url：/user/check/{param}/{type}
     * @param param
     * @param type：可选参数有1、2、3，分别代表username、phone、email
     * @return
     */
    @RequestMapping(value="/user/check/{param}/{type}", method=RequestMethod.GET)
    @ResponseBody
    public TaotaoResult checkData(@PathVariable String param, @PathVariable Integer type) {
        // 1. 引入服务
        // 2. 注入服务
        // 3. 调用
        return registerService.checkData(param, type);
    }

    /**
     * 注册用户
     * url：/user/register
     * 参数：
     * 		username
     * 		password
     * 		phone
     * 		email
     * 请求的方法：post
     * 返回值：json数据
     * @param user
     * @return
     */
    @RequestMapping(value="/user/register", method=RequestMethod.POST)
    @ResponseBody
    public TaotaoResult register(TbUser user) {
        TaotaoResult result = registerService.register(user);
        return result;
    }

}
